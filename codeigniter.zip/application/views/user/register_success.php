<p>Thanks for registering.</p>
<p> Before you can access our website please activate your account that was sent to your registered email.</p>
