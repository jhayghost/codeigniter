Author: Teofilo Tabunan III
Date: 02-27-13
Email: jhayghost@yahoo.com

===== How to install ===

1) execute the database.sql to your database
2) open /application/config/database.php and change the database configuration
3) if you are running in sub-folder open .htaccess and change the rewrite rule